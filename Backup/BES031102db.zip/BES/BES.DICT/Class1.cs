using System;
using System.Collections.Generic;
using System.Text;

namespace BES.DICT
{
    public class Class1
    {
    }
}
