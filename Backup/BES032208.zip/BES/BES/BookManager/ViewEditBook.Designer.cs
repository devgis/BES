﻿namespace BES.Forms.BookManager
{
    partial class ViewEditBook
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewEditBook));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.pbCover = new System.Windows.Forms.PictureBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.tbJianJie = new System.Windows.Forms.TextBox();
            this.tbISBN = new System.Windows.Forms.TextBox();
            this.tbTITLE = new System.Windows.Forms.TextBox();
            this.tbSERIES = new System.Windows.Forms.TextBox();
            this.tbAUTHOR = new System.Windows.Forms.TextBox();
            this.tbTRANSLATOR = new System.Windows.Forms.TextBox();
            this.cbDEPARTMENT = new System.Windows.Forms.ComboBox();
            this.cbCLASS = new Infragistics.Win.UltraWinGrid.UltraCombo();
            this.tbPRICE = new System.Windows.Forms.TextBox();
            this.tbRDIS = new System.Windows.Forms.TextBox();
            this.dtpPUBDATE = new System.Windows.Forms.DateTimePicker();
            this.cbBINDING = new System.Windows.Forms.ComboBox();
            this.cbBKSIZE = new System.Windows.Forms.ComboBox();
            this.tbEDITION = new System.Windows.Forms.TextBox();
            this.tbNPRINT = new System.Windows.Forms.TextBox();
            this.tbPAGES = new System.Windows.Forms.TextBox();
            this.tbNPRINTCount = new System.Windows.Forms.TextBox();
            this.cbPublisher = new Infragistics.Win.UltraWinGrid.UltraCombo();
            this.tbDuZheDingWei = new System.Windows.Forms.TextBox();
            this.tbMaiDian = new System.Windows.Forms.TextBox();
            this.tbShangJiaJianYi = new System.Windows.Forms.TextBox();
            this.tbCREATBY = new System.Windows.Forms.TextBox();
            this.tbCREDATE = new System.Windows.Forms.TextBox();
            this.tbMODBY = new System.Windows.Forms.TextBox();
            this.tbMODDATE = new System.Windows.Forms.TextBox();
            this.cbISBN = new System.Windows.Forms.CheckBox();
            this.label27 = new System.Windows.Forms.Label();
            this.tbWORDS = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.cbPYSTYPE = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tbCLASS = new System.Windows.Forms.TextBox();
            this.tbPKQTY = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbNew = new System.Windows.Forms.ToolStripButton();
            this.tsbDelete = new System.Windows.Forms.ToolStripButton();
            this.tsbSave = new System.Windows.Forms.ToolStripButton();
            this.tsbUploadPhoto = new System.Windows.Forms.ToolStripButton();
            this.tsbExit = new System.Windows.Forms.ToolStripButton();
            this.pMain = new System.Windows.Forms.Panel();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCover)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbCLASS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbPublisher)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.pMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 16;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142042F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142042F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142042F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142042F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142042F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142042F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142042F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142042F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142042F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142042F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142042F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.147757F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.147757F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.142042F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 191F));
            this.tableLayoutPanel1.Controls.Add(this.label1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label3, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.label4, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label5, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.label6, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.label7, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.label8, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.label9, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.label10, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.label11, 1, 13);
            this.tableLayoutPanel1.Controls.Add(this.label12, 1, 14);
            this.tableLayoutPanel1.Controls.Add(this.label13, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.label14, 3, 8);
            this.tableLayoutPanel1.Controls.Add(this.label15, 5, 8);
            this.tableLayoutPanel1.Controls.Add(this.label16, 5, 9);
            this.tableLayoutPanel1.Controls.Add(this.label17, 7, 9);
            this.tableLayoutPanel1.Controls.Add(this.label18, 5, 10);
            this.tableLayoutPanel1.Controls.Add(this.label19, 7, 10);
            this.tableLayoutPanel1.Controls.Add(this.label21, 5, 13);
            this.tableLayoutPanel1.Controls.Add(this.pbCover, 9, 1);
            this.tableLayoutPanel1.Controls.Add(this.label22, 9, 6);
            this.tableLayoutPanel1.Controls.Add(this.label23, 9, 7);
            this.tableLayoutPanel1.Controls.Add(this.label24, 9, 8);
            this.tableLayoutPanel1.Controls.Add(this.label25, 9, 9);
            this.tableLayoutPanel1.Controls.Add(this.tbJianJie, 11, 2);
            this.tableLayoutPanel1.Controls.Add(this.tbISBN, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.tbTITLE, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.tbSERIES, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.tbAUTHOR, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.tbTRANSLATOR, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.cbDEPARTMENT, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.cbCLASS, 5, 6);
            this.tableLayoutPanel1.Controls.Add(this.tbPRICE, 2, 8);
            this.tableLayoutPanel1.Controls.Add(this.tbRDIS, 4, 8);
            this.tableLayoutPanel1.Controls.Add(this.dtpPUBDATE, 6, 8);
            this.tableLayoutPanel1.Controls.Add(this.cbBINDING, 2, 9);
            this.tableLayoutPanel1.Controls.Add(this.cbBKSIZE, 2, 10);
            this.tableLayoutPanel1.Controls.Add(this.tbEDITION, 6, 9);
            this.tableLayoutPanel1.Controls.Add(this.tbNPRINT, 6, 10);
            this.tableLayoutPanel1.Controls.Add(this.tbPAGES, 8, 9);
            this.tableLayoutPanel1.Controls.Add(this.tbNPRINTCount, 8, 10);
            this.tableLayoutPanel1.Controls.Add(this.cbPublisher, 2, 11);
            this.tableLayoutPanel1.Controls.Add(this.tbDuZheDingWei, 2, 13);
            this.tableLayoutPanel1.Controls.Add(this.tbMaiDian, 6, 13);
            this.tableLayoutPanel1.Controls.Add(this.tbShangJiaJianYi, 2, 14);
            this.tableLayoutPanel1.Controls.Add(this.tbCREATBY, 10, 6);
            this.tableLayoutPanel1.Controls.Add(this.tbCREDATE, 10, 7);
            this.tableLayoutPanel1.Controls.Add(this.tbMODBY, 10, 8);
            this.tableLayoutPanel1.Controls.Add(this.tbMODDATE, 10, 9);
            this.tableLayoutPanel1.Controls.Add(this.cbISBN, 7, 1);
            this.tableLayoutPanel1.Controls.Add(this.label27, 9, 10);
            this.tableLayoutPanel1.Controls.Add(this.tbWORDS, 10, 10);
            this.tableLayoutPanel1.Controls.Add(this.label26, 11, 1);
            this.tableLayoutPanel1.Controls.Add(this.cbPYSTYPE, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.label20, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.tbCLASS, 5, 7);
            this.tableLayoutPanel1.Controls.Add(this.tbPKQTY, 6, 11);
            this.tableLayoutPanel1.Controls.Add(this.label28, 5, 11);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 16;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.143267F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.143267F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.143267F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.143267F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.143267F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.143267F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.143267F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.143267F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.143267F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.143267F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.143267F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.143267F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.140408F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.140408F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1001, 462);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(13, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "ISBN";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(13, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "书名";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "丛书名";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "作者";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 133);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "译者";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(13, 165);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 32);
            this.label6.TabIndex = 5;
            this.label6.Text = "一级分类";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Red;
            this.label7.Location = new System.Drawing.Point(13, 229);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "定价";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(13, 261);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "装帧";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(13, 293);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 20);
            this.label9.TabIndex = 8;
            this.label9.Text = "开本";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(13, 325);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 20);
            this.label10.TabIndex = 9;
            this.label10.Text = "版别";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 389);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 32);
            this.label11.TabIndex = 10;
            this.label11.Text = "读者定位";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 421);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 32);
            this.label12.TabIndex = 11;
            this.label12.Text = "上架建议";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Red;
            this.label13.Location = new System.Drawing.Point(184, 165);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(51, 32);
            this.label13.TabIndex = 12;
            this.label13.Text = "中图法分类";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Red;
            this.label14.Location = new System.Drawing.Point(127, 229);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 32);
            this.label14.TabIndex = 13;
            this.label14.Text = "发货折扣";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Red;
            this.label15.Location = new System.Drawing.Point(241, 229);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(51, 32);
            this.label15.TabIndex = 14;
            this.label15.Text = "出版日期";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(241, 261);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(37, 20);
            this.label16.TabIndex = 15;
            this.label16.Text = "版次";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(355, 261);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(37, 20);
            this.label17.TabIndex = 16;
            this.label17.Text = "页数";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(241, 293);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(37, 20);
            this.label18.TabIndex = 17;
            this.label18.Text = "印次";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(355, 293);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(37, 20);
            this.label19.TabIndex = 18;
            this.label19.Text = "印数";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(241, 389);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(37, 20);
            this.label21.TabIndex = 20;
            this.label21.Text = "卖点";
            // 
            // pbCover
            // 
            this.pbCover.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbCover.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tableLayoutPanel1.SetColumnSpan(this.pbCover, 2);
            this.pbCover.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbCover.Location = new System.Drawing.Point(469, 8);
            this.pbCover.Name = "pbCover";
            this.tableLayoutPanel1.SetRowSpan(this.pbCover, 5);
            this.pbCover.Size = new System.Drawing.Size(108, 154);
            this.pbCover.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCover.TabIndex = 21;
            this.pbCover.TabStop = false;
            this.toolTip1.SetToolTip(this.pbCover, "双击可查看大图");
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(469, 165);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(51, 20);
            this.label22.TabIndex = 22;
            this.label22.Text = "创建人";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(469, 197);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(51, 32);
            this.label23.TabIndex = 23;
            this.label23.Text = "创建日期";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(469, 229);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(51, 20);
            this.label24.TabIndex = 24;
            this.label24.Text = "修改人";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(469, 261);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(51, 32);
            this.label25.TabIndex = 25;
            this.label25.Text = "修改日期";
            // 
            // tbJianJie
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.tbJianJie, 4);
            this.tbJianJie.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbJianJie.Location = new System.Drawing.Point(583, 40);
            this.tbJianJie.Multiline = true;
            this.tbJianJie.Name = "tbJianJie";
            this.tableLayoutPanel1.SetRowSpan(this.tbJianJie, 13);
            this.tbJianJie.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbJianJie.Size = new System.Drawing.Size(222, 410);
            this.tbJianJie.TabIndex = 24;
            this.tbJianJie.DoubleClick += new System.EventHandler(this.tbJianJie_DoubleClick);
            // 
            // tbISBN
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.tbISBN, 5);
            this.tbISBN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbISBN.Location = new System.Drawing.Point(70, 8);
            this.tbISBN.Name = "tbISBN";
            this.tbISBN.Size = new System.Drawing.Size(279, 26);
            this.tbISBN.TabIndex = 0;
            // 
            // tbTITLE
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.tbTITLE, 7);
            this.tbTITLE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbTITLE.Location = new System.Drawing.Point(70, 40);
            this.tbTITLE.Name = "tbTITLE";
            this.tbTITLE.Size = new System.Drawing.Size(393, 26);
            this.tbTITLE.TabIndex = 2;
            // 
            // tbSERIES
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.tbSERIES, 7);
            this.tbSERIES.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbSERIES.Location = new System.Drawing.Point(70, 72);
            this.tbSERIES.Name = "tbSERIES";
            this.tbSERIES.Size = new System.Drawing.Size(393, 26);
            this.tbSERIES.TabIndex = 3;
            // 
            // tbAUTHOR
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.tbAUTHOR, 7);
            this.tbAUTHOR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbAUTHOR.Location = new System.Drawing.Point(70, 104);
            this.tbAUTHOR.Name = "tbAUTHOR";
            this.tbAUTHOR.Size = new System.Drawing.Size(393, 26);
            this.tbAUTHOR.TabIndex = 4;
            // 
            // tbTRANSLATOR
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.tbTRANSLATOR, 7);
            this.tbTRANSLATOR.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbTRANSLATOR.Location = new System.Drawing.Point(70, 136);
            this.tbTRANSLATOR.Name = "tbTRANSLATOR";
            this.tbTRANSLATOR.Size = new System.Drawing.Size(393, 26);
            this.tbTRANSLATOR.TabIndex = 5;
            // 
            // cbDEPARTMENT
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.cbDEPARTMENT, 2);
            this.cbDEPARTMENT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbDEPARTMENT.FormattingEnabled = true;
            this.cbDEPARTMENT.Location = new System.Drawing.Point(70, 168);
            this.cbDEPARTMENT.Name = "cbDEPARTMENT";
            this.cbDEPARTMENT.Size = new System.Drawing.Size(108, 28);
            this.cbDEPARTMENT.TabIndex = 6;
            // 
            // cbCLASS
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.cbCLASS, 3);
            this.cbCLASS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbCLASS.Location = new System.Drawing.Point(241, 168);
            this.cbCLASS.Name = "cbCLASS";
            this.cbCLASS.Size = new System.Drawing.Size(165, 29);
            this.cbCLASS.TabIndex = 7;
            this.cbCLASS.TextChanged += new System.EventHandler(this.cbCLASS_TextChanged);
            // 
            // tbPRICE
            // 
            this.tbPRICE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbPRICE.Location = new System.Drawing.Point(70, 232);
            this.tbPRICE.Name = "tbPRICE";
            this.tbPRICE.Size = new System.Drawing.Size(51, 26);
            this.tbPRICE.TabIndex = 9;
            this.tbPRICE.Leave += new System.EventHandler(this.tbPRICE_Leave);
            // 
            // tbRDIS
            // 
            this.tbRDIS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbRDIS.Location = new System.Drawing.Point(184, 232);
            this.tbRDIS.Name = "tbRDIS";
            this.tbRDIS.Size = new System.Drawing.Size(51, 26);
            this.tbRDIS.TabIndex = 10;
            this.tbRDIS.TextChanged += new System.EventHandler(this.tbRDIS_TextChanged);
            this.tbRDIS.Leave += new System.EventHandler(this.tbRDIS_Leave);
            // 
            // dtpPUBDATE
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.dtpPUBDATE, 3);
            this.dtpPUBDATE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtpPUBDATE.Location = new System.Drawing.Point(298, 232);
            this.dtpPUBDATE.Name = "dtpPUBDATE";
            this.dtpPUBDATE.Size = new System.Drawing.Size(165, 26);
            this.dtpPUBDATE.TabIndex = 11;
            // 
            // cbBINDING
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.cbBINDING, 3);
            this.cbBINDING.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbBINDING.FormattingEnabled = true;
            this.cbBINDING.Location = new System.Drawing.Point(70, 264);
            this.cbBINDING.Name = "cbBINDING";
            this.cbBINDING.Size = new System.Drawing.Size(165, 28);
            this.cbBINDING.TabIndex = 12;
            // 
            // cbBKSIZE
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.cbBKSIZE, 3);
            this.cbBKSIZE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbBKSIZE.FormattingEnabled = true;
            this.cbBKSIZE.Location = new System.Drawing.Point(70, 296);
            this.cbBKSIZE.Name = "cbBKSIZE";
            this.cbBKSIZE.Size = new System.Drawing.Size(165, 28);
            this.cbBKSIZE.TabIndex = 15;
            // 
            // tbEDITION
            // 
            this.tbEDITION.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbEDITION.Location = new System.Drawing.Point(298, 264);
            this.tbEDITION.Name = "tbEDITION";
            this.tbEDITION.Size = new System.Drawing.Size(51, 26);
            this.tbEDITION.TabIndex = 13;
            this.tbEDITION.TextChanged += new System.EventHandler(this.tbEDITION_TextChanged);
            // 
            // tbNPRINT
            // 
            this.tbNPRINT.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbNPRINT.Location = new System.Drawing.Point(298, 296);
            this.tbNPRINT.Name = "tbNPRINT";
            this.tbNPRINT.Size = new System.Drawing.Size(51, 26);
            this.tbNPRINT.TabIndex = 16;
            this.tbNPRINT.TextChanged += new System.EventHandler(this.tbNPRINT_TextChanged);
            // 
            // tbPAGES
            // 
            this.tbPAGES.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbPAGES.Location = new System.Drawing.Point(412, 264);
            this.tbPAGES.Name = "tbPAGES";
            this.tbPAGES.Size = new System.Drawing.Size(51, 26);
            this.tbPAGES.TabIndex = 14;
            this.tbPAGES.TextChanged += new System.EventHandler(this.tbPAGES_TextChanged);
            // 
            // tbNPRINTCount
            // 
            this.tbNPRINTCount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbNPRINTCount.Location = new System.Drawing.Point(412, 296);
            this.tbNPRINTCount.Name = "tbNPRINTCount";
            this.tbNPRINTCount.Size = new System.Drawing.Size(51, 26);
            this.tbNPRINTCount.TabIndex = 17;
            this.tbNPRINTCount.TextChanged += new System.EventHandler(this.tbNPRINTCount_TextChanged);
            // 
            // cbPublisher
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.cbPublisher, 3);
            this.cbPublisher.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbPublisher.Location = new System.Drawing.Point(70, 328);
            this.cbPublisher.Name = "cbPublisher";
            this.cbPublisher.Size = new System.Drawing.Size(165, 29);
            this.cbPublisher.TabIndex = 19;
            // 
            // tbDuZheDingWei
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.tbDuZheDingWei, 3);
            this.tbDuZheDingWei.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbDuZheDingWei.Location = new System.Drawing.Point(70, 392);
            this.tbDuZheDingWei.Name = "tbDuZheDingWei";
            this.tbDuZheDingWei.Size = new System.Drawing.Size(165, 26);
            this.tbDuZheDingWei.TabIndex = 21;
            // 
            // tbMaiDian
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.tbMaiDian, 5);
            this.tbMaiDian.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbMaiDian.Location = new System.Drawing.Point(298, 392);
            this.tbMaiDian.Name = "tbMaiDian";
            this.tbMaiDian.Size = new System.Drawing.Size(279, 26);
            this.tbMaiDian.TabIndex = 22;
            // 
            // tbShangJiaJianYi
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.tbShangJiaJianYi, 9);
            this.tbShangJiaJianYi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbShangJiaJianYi.Location = new System.Drawing.Point(70, 424);
            this.tbShangJiaJianYi.Name = "tbShangJiaJianYi";
            this.tbShangJiaJianYi.Size = new System.Drawing.Size(507, 26);
            this.tbShangJiaJianYi.TabIndex = 23;
            // 
            // tbCREATBY
            // 
            this.tbCREATBY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbCREATBY.Location = new System.Drawing.Point(526, 168);
            this.tbCREATBY.Name = "tbCREATBY";
            this.tbCREATBY.ReadOnly = true;
            this.tbCREATBY.Size = new System.Drawing.Size(51, 26);
            this.tbCREATBY.TabIndex = 58;
            // 
            // tbCREDATE
            // 
            this.tbCREDATE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbCREDATE.Location = new System.Drawing.Point(526, 200);
            this.tbCREDATE.Name = "tbCREDATE";
            this.tbCREDATE.ReadOnly = true;
            this.tbCREDATE.Size = new System.Drawing.Size(51, 26);
            this.tbCREDATE.TabIndex = 59;
            // 
            // tbMODBY
            // 
            this.tbMODBY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbMODBY.Location = new System.Drawing.Point(526, 232);
            this.tbMODBY.Name = "tbMODBY";
            this.tbMODBY.ReadOnly = true;
            this.tbMODBY.Size = new System.Drawing.Size(51, 26);
            this.tbMODBY.TabIndex = 60;
            // 
            // tbMODDATE
            // 
            this.tbMODDATE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbMODDATE.Location = new System.Drawing.Point(526, 264);
            this.tbMODDATE.Name = "tbMODDATE";
            this.tbMODDATE.ReadOnly = true;
            this.tbMODDATE.Size = new System.Drawing.Size(51, 26);
            this.tbMODDATE.TabIndex = 61;
            // 
            // cbISBN
            // 
            this.cbISBN.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.cbISBN, 2);
            this.cbISBN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbISBN.Location = new System.Drawing.Point(355, 8);
            this.cbISBN.Name = "cbISBN";
            this.cbISBN.Size = new System.Drawing.Size(108, 26);
            this.cbISBN.TabIndex = 1;
            this.cbISBN.Text = "是否ISBN";
            this.cbISBN.UseVisualStyleBackColor = true;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(469, 293);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(37, 20);
            this.label27.TabIndex = 63;
            this.label27.Text = "字数";
            // 
            // tbWORDS
            // 
            this.tbWORDS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbWORDS.Location = new System.Drawing.Point(526, 296);
            this.tbWORDS.Name = "tbWORDS";
            this.tbWORDS.Size = new System.Drawing.Size(51, 26);
            this.tbWORDS.TabIndex = 18;
            this.tbWORDS.TextChanged += new System.EventHandler(this.tbWORDS_TextChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.label26, 2);
            this.label26.Location = new System.Drawing.Point(583, 5);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(65, 20);
            this.label26.TabIndex = 28;
            this.label26.Text = "图书简介";
            // 
            // cbPYSTYPE
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.cbPYSTYPE, 2);
            this.cbPYSTYPE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbPYSTYPE.FormattingEnabled = true;
            this.cbPYSTYPE.Location = new System.Drawing.Point(70, 200);
            this.cbPYSTYPE.Name = "cbPYSTYPE";
            this.cbPYSTYPE.Size = new System.Drawing.Size(108, 28);
            this.cbPYSTYPE.TabIndex = 8;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(13, 197);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(51, 32);
            this.label20.TabIndex = 68;
            this.label20.Text = "货品种类：";
            // 
            // tbCLASS
            // 
            this.tableLayoutPanel1.SetColumnSpan(this.tbCLASS, 3);
            this.tbCLASS.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbCLASS.Location = new System.Drawing.Point(241, 200);
            this.tbCLASS.Name = "tbCLASS";
            this.tbCLASS.ReadOnly = true;
            this.tbCLASS.Size = new System.Drawing.Size(165, 26);
            this.tbCLASS.TabIndex = 69;
            // 
            // tbPKQTY
            // 
            this.tbPKQTY.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbPKQTY.Location = new System.Drawing.Point(298, 328);
            this.tbPKQTY.Name = "tbPKQTY";
            this.tbPKQTY.Size = new System.Drawing.Size(51, 26);
            this.tbPKQTY.TabIndex = 20;
            this.tbPKQTY.TextChanged += new System.EventHandler(this.tbPKQTY_TextChanged);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(241, 325);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(51, 20);
            this.label28.TabIndex = 71;
            this.label28.Text = "包册数";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbNew,
            this.tsbDelete,
            this.tsbSave,
            this.tsbUploadPhoto,
            this.tsbExit});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1001, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbNew
            // 
            this.tsbNew.Image = ((System.Drawing.Image)(resources.GetObject("tsbNew.Image")));
            this.tsbNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNew.Name = "tsbNew";
            this.tsbNew.Size = new System.Drawing.Size(67, 22);
            this.tsbNew.Text = "新增(&A)";
            this.tsbNew.Click += new System.EventHandler(this.tsbNew_Click);
            // 
            // tsbDelete
            // 
            this.tsbDelete.Image = ((System.Drawing.Image)(resources.GetObject("tsbDelete.Image")));
            this.tsbDelete.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDelete.Name = "tsbDelete";
            this.tsbDelete.Size = new System.Drawing.Size(67, 22);
            this.tsbDelete.Text = "删除(&D)";
            this.tsbDelete.Click += new System.EventHandler(this.tsbDelete_Click);
            // 
            // tsbSave
            // 
            this.tsbSave.Image = ((System.Drawing.Image)(resources.GetObject("tsbSave.Image")));
            this.tsbSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSave.Name = "tsbSave";
            this.tsbSave.Size = new System.Drawing.Size(67, 22);
            this.tsbSave.Text = "保存(&S)";
            this.tsbSave.Click += new System.EventHandler(this.tsbSave_Click);
            // 
            // tsbUploadPhoto
            // 
            this.tsbUploadPhoto.Image = ((System.Drawing.Image)(resources.GetObject("tsbUploadPhoto.Image")));
            this.tsbUploadPhoto.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbUploadPhoto.Name = "tsbUploadPhoto";
            this.tsbUploadPhoto.Size = new System.Drawing.Size(91, 22);
            this.tsbUploadPhoto.Text = "图片上传(&T)";
            this.tsbUploadPhoto.Click += new System.EventHandler(this.tsbUploadPhoto_Click);
            // 
            // tsbExit
            // 
            this.tsbExit.Image = ((System.Drawing.Image)(resources.GetObject("tsbExit.Image")));
            this.tsbExit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbExit.Name = "tsbExit";
            this.tsbExit.Size = new System.Drawing.Size(67, 22);
            this.tsbExit.Text = "退出(&E)";
            this.tsbExit.Click += new System.EventHandler(this.tsbExit_Click);
            // 
            // pMain
            // 
            this.pMain.Controls.Add(this.tableLayoutPanel1);
            this.pMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pMain.Location = new System.Drawing.Point(0, 25);
            this.pMain.Name = "pMain";
            this.pMain.Size = new System.Drawing.Size(1001, 462);
            this.pMain.TabIndex = 2;
            // 
            // ViewEditBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1001, 487);
            this.Controls.Add(this.pMain);
            this.Controls.Add(this.toolStrip1);
            this.Name = "ViewEditBook";
            this.Text = "查看编辑图书信息";
            this.Load += new System.EventHandler(this.AddBook_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCover)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbCLASS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbPublisher)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.pMain.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbNew;
        private System.Windows.Forms.ToolStripButton tsbSave;
        private System.Windows.Forms.ToolStripButton tsbDelete;
        private System.Windows.Forms.ToolStripButton tsbUploadPhoto;
        private System.Windows.Forms.ToolStripButton tsbExit;
        private System.Windows.Forms.Panel pMain;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.PictureBox pbCover;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox tbJianJie;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox tbISBN;
        private System.Windows.Forms.TextBox tbTITLE;
        private System.Windows.Forms.TextBox tbSERIES;
        private System.Windows.Forms.TextBox tbAUTHOR;
        private System.Windows.Forms.TextBox tbTRANSLATOR;
        private System.Windows.Forms.ComboBox cbDEPARTMENT;
        private Infragistics.Win.UltraWinGrid.UltraCombo cbCLASS;
        private System.Windows.Forms.TextBox tbPRICE;
        private System.Windows.Forms.TextBox tbRDIS;
        private System.Windows.Forms.DateTimePicker dtpPUBDATE;
        private System.Windows.Forms.ComboBox cbBINDING;
        private System.Windows.Forms.ComboBox cbBKSIZE;
        private System.Windows.Forms.TextBox tbEDITION;
        private System.Windows.Forms.TextBox tbNPRINT;
        private System.Windows.Forms.TextBox tbPAGES;
        private System.Windows.Forms.TextBox tbNPRINTCount;
        private Infragistics.Win.UltraWinGrid.UltraCombo cbPublisher;
        private System.Windows.Forms.TextBox tbDuZheDingWei;
        private System.Windows.Forms.TextBox tbMaiDian;
        private System.Windows.Forms.TextBox tbShangJiaJianYi;
        private System.Windows.Forms.TextBox tbCREATBY;
        private System.Windows.Forms.TextBox tbCREDATE;
        private System.Windows.Forms.TextBox tbMODBY;
        private System.Windows.Forms.TextBox tbMODDATE;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.CheckBox cbISBN;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox tbWORDS;
        private System.Windows.Forms.ComboBox cbPYSTYPE;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tbCLASS;
        private System.Windows.Forms.TextBox tbPKQTY;
        private System.Windows.Forms.Label label28;
    }
}